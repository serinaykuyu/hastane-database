﻿namespace HastaneVeritabani
{
    partial class FrmAnaMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAnaMenu));
            label1 = new Label();
            panel1 = new Panel();
            btnCikis = new Button();
            pictureBox1 = new PictureBox();
            lblTC = new Label();
            lblAdSoyad = new Label();
            btnHastaIslemleri = new Button();
            btnRandevu = new Button();
            btnDoktorPanel = new Button();
            btnRaporlar = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(190, 83);
            label1.Name = "label1";
            label1.Size = new Size(280, 42);
            label1.TabIndex = 0;
            label1.Text = "HOŞGELDİNİZ";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.Controls.Add(btnCikis);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(lblTC);
            panel1.Controls.Add(lblAdSoyad);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(666, 63);
            panel1.TabIndex = 1;
            // 
            // btnCikis
            // 
            btnCikis.Location = new Point(577, 12);
            btnCikis.Name = "btnCikis";
            btnCikis.Size = new Size(77, 41);
            btnCikis.TabIndex = 3;
            btnCikis.Text = "Çıkış Yap";
            btnCikis.UseVisualStyleBackColor = true;
            btnCikis.Click += btnCikis_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(523, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 41);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // lblTC
            // 
            lblTC.AutoSize = true;
            lblTC.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblTC.ForeColor = SystemColors.Window;
            lblTC.Location = new Point(12, 31);
            lblTC.Name = "lblTC";
            lblTC.Size = new Size(59, 22);
            lblTC.TabIndex = 1;
            lblTC.Text = "label2";
            // 
            // lblAdSoyad
            // 
            lblAdSoyad.AutoSize = true;
            lblAdSoyad.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblAdSoyad.ForeColor = SystemColors.Window;
            lblAdSoyad.Location = new Point(12, 9);
            lblAdSoyad.Name = "lblAdSoyad";
            lblAdSoyad.Size = new Size(59, 22);
            lblAdSoyad.TabIndex = 0;
            lblAdSoyad.Text = "label2";
            // 
            // btnHastaIslemleri
            // 
            btnHastaIslemleri.BackColor = Color.Teal;
            btnHastaIslemleri.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnHastaIslemleri.ForeColor = SystemColors.Window;
            btnHastaIslemleri.Location = new Point(73, 144);
            btnHastaIslemleri.Name = "btnHastaIslemleri";
            btnHastaIslemleri.Size = new Size(245, 81);
            btnHastaIslemleri.TabIndex = 2;
            btnHastaIslemleri.Text = "HASTA KAYIT / DÜZENLEME";
            btnHastaIslemleri.UseVisualStyleBackColor = false;
            btnHastaIslemleri.Click += btnHastaIslemleri_Click;
            // 
            // btnRandevu
            // 
            btnRandevu.BackColor = Color.Teal;
            btnRandevu.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnRandevu.ForeColor = SystemColors.Window;
            btnRandevu.Location = new Point(336, 144);
            btnRandevu.Name = "btnRandevu";
            btnRandevu.Size = new Size(259, 81);
            btnRandevu.TabIndex = 3;
            btnRandevu.Text = "RANDEVU ALMA";
            btnRandevu.UseVisualStyleBackColor = false;
            btnRandevu.Click += btnRandevu_Click;
            // 
            // btnDoktorPanel
            // 
            btnDoktorPanel.BackColor = Color.Teal;
            btnDoktorPanel.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnDoktorPanel.ForeColor = SystemColors.Window;
            btnDoktorPanel.Location = new Point(73, 231);
            btnDoktorPanel.Name = "btnDoktorPanel";
            btnDoktorPanel.Size = new Size(245, 97);
            btnDoktorPanel.TabIndex = 4;
            btnDoktorPanel.Text = "DOKTOR PANELİ";
            btnDoktorPanel.UseVisualStyleBackColor = false;
            btnDoktorPanel.Click += btnDoktorPanel_Click;
            // 
            // btnRaporlar
            // 
            btnRaporlar.BackColor = Color.Teal;
            btnRaporlar.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnRaporlar.ForeColor = SystemColors.Window;
            btnRaporlar.Location = new Point(336, 231);
            btnRaporlar.Name = "btnRaporlar";
            btnRaporlar.Size = new Size(259, 97);
            btnRaporlar.TabIndex = 5;
            btnRaporlar.Text = "RAPORLAR / İSTATİSTİK";
            btnRaporlar.UseVisualStyleBackColor = false;
            btnRaporlar.Click += btnRaporlar_Click;
            // 
            // FrmAnaMenu
            // 
            AutoScaleDimensions = new SizeF(9F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(666, 359);
            Controls.Add(btnRaporlar);
            Controls.Add(btnDoktorPanel);
            Controls.Add(btnRandevu);
            Controls.Add(btnHastaIslemleri);
            Controls.Add(panel1);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            Name = "FrmAnaMenu";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hastane Yönetim Sistemi - Ana Menü";
            FormClosed += FrmAnaMenu_FormClosed;
            Load += FrmAnaMenu_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Label lblTC;
        private Label lblAdSoyad;
        private Button btnHastaIslemleri;
        private Button btnRandevu;
        private Button btnDoktorPanel;
        private Button btnRaporlar;
        private PictureBox pictureBox1;
        private Button btnCikis;
    }
}