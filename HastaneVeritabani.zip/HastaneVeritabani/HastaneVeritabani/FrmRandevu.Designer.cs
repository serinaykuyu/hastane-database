﻿namespace HastaneVeritabani
{
    partial class FrmRandevu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRandevu));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            cmbSehir = new ComboBox();
            cmbHastane = new ComboBox();
            cmbPoliklinik = new ComboBox();
            cmbDoktor = new ComboBox();
            mskTC = new MaskedTextBox();
            dtpTarih = new DateTimePicker();
            btnRandevuAl = new Button();
            dataGridView1 = new DataGridView();
            btnRandevuIptal = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label1.Location = new Point(95, 31);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(58, 22);
            label1.TabIndex = 0;
            label1.Text = "Şehir:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label2.Location = new Point(72, 69);
            label2.Name = "label2";
            label2.Size = new Size(82, 22);
            label2.TabIndex = 1;
            label2.Text = "Hastane:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label3.Location = new Point(60, 109);
            label3.Name = "label3";
            label3.Size = new Size(94, 22);
            label3.TabIndex = 2;
            label3.Text = "Poliklinik:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label4.Location = new Point(80, 148);
            label4.Name = "label4";
            label4.Size = new Size(74, 22);
            label4.TabIndex = 3;
            label4.Text = "Doktor:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label5.Location = new Point(59, 190);
            label5.Name = "label5";
            label5.Size = new Size(95, 22);
            label5.TabIndex = 4;
            label5.Text = "Hasta TC:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 14.25F, FontStyle.Bold);
            label6.Location = new Point(53, 230);
            label6.Name = "label6";
            label6.Size = new Size(101, 22);
            label6.TabIndex = 5;
            label6.Text = "Tarih/Saat:";
            // 
            // cmbSehir
            // 
            cmbSehir.FormattingEnabled = true;
            cmbSehir.Location = new Point(160, 28);
            cmbSehir.Name = "cmbSehir";
            cmbSehir.Size = new Size(185, 25);
            cmbSehir.TabIndex = 6;
            cmbSehir.SelectedIndexChanged += cmbSehir_SelectedIndexChanged;
            // 
            // cmbHastane
            // 
            cmbHastane.FormattingEnabled = true;
            cmbHastane.Location = new Point(160, 66);
            cmbHastane.Name = "cmbHastane";
            cmbHastane.Size = new Size(185, 25);
            cmbHastane.TabIndex = 7;
            cmbHastane.SelectedIndexChanged += cmbHastane_SelectedIndexChanged;
            // 
            // cmbPoliklinik
            // 
            cmbPoliklinik.FormattingEnabled = true;
            cmbPoliklinik.Location = new Point(160, 106);
            cmbPoliklinik.Name = "cmbPoliklinik";
            cmbPoliklinik.Size = new Size(185, 25);
            cmbPoliklinik.TabIndex = 8;
            cmbPoliklinik.SelectedIndexChanged += cmbPoliklinik_SelectedIndexChanged;
            // 
            // cmbDoktor
            // 
            cmbDoktor.FormattingEnabled = true;
            cmbDoktor.Location = new Point(160, 145);
            cmbDoktor.Name = "cmbDoktor";
            cmbDoktor.Size = new Size(185, 25);
            cmbDoktor.TabIndex = 9;
            // 
            // mskTC
            // 
            mskTC.Location = new Point(160, 187);
            mskTC.Mask = "00000000000";
            mskTC.Name = "mskTC";
            mskTC.Size = new Size(185, 25);
            mskTC.TabIndex = 10;
            // 
            // dtpTarih
            // 
            dtpTarih.CustomFormat = "dd.MM.yyyy - HH:mm";
            dtpTarih.Format = DateTimePickerFormat.Custom;
            dtpTarih.Location = new Point(160, 227);
            dtpTarih.Name = "dtpTarih";
            dtpTarih.Size = new Size(185, 25);
            dtpTarih.TabIndex = 11;
            // 
            // btnRandevuAl
            // 
            btnRandevuAl.Location = new Point(59, 285);
            btnRandevuAl.Name = "btnRandevuAl";
            btnRandevuAl.Size = new Size(139, 36);
            btnRandevuAl.TabIndex = 12;
            btnRandevuAl.Text = "Randevu Al";
            btnRandevuAl.UseVisualStyleBackColor = true;
            btnRandevuAl.Click += btnRandevuAl_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.Window;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(384, 28);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(378, 293);
            dataGridView1.TabIndex = 13;
            // 
            // btnRandevuIptal
            // 
            btnRandevuIptal.Location = new Point(204, 285);
            btnRandevuIptal.Name = "btnRandevuIptal";
            btnRandevuIptal.Size = new Size(141, 36);
            btnRandevuIptal.TabIndex = 14;
            btnRandevuIptal.Text = "Randevu İptal Et";
            btnRandevuIptal.UseVisualStyleBackColor = true;
            btnRandevuIptal.Click += btnRandevuIptal_Click;
            // 
            // FrmRandevu
            // 
            AutoScaleDimensions = new SizeF(9F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(789, 348);
            Controls.Add(btnRandevuIptal);
            Controls.Add(dataGridView1);
            Controls.Add(btnRandevuAl);
            Controls.Add(dtpTarih);
            Controls.Add(mskTC);
            Controls.Add(cmbDoktor);
            Controls.Add(cmbPoliklinik);
            Controls.Add(cmbHastane);
            Controls.Add(cmbSehir);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            Name = "FrmRandevu";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Randevu Paneli";
            Load += FrmRandevu_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox cmbSehir;
        private ComboBox cmbHastane;
        private ComboBox cmbPoliklinik;
        private ComboBox cmbDoktor;
        private MaskedTextBox mskTC;
        private DateTimePicker dtpTarih;
        private Button btnRandevuAl;
        private DataGridView dataGridView1;
        private Button btnRandevuIptal;
    }
}