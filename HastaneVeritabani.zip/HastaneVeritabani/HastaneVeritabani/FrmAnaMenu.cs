﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmAnaMenu : Form
    {
        public FrmAnaMenu()
        {
            InitializeComponent();
        }

        public string tcKimlikNo;
        public string adSoyad;
        public string gorev;
        bool cikisYapiliyor = false;

        private void FrmAnaMenu_Load(object sender, EventArgs e)
        {
            lblTC.Text = "TC: " + tcKimlikNo;
            lblAdSoyad.Text = "Sn. " + adSoyad;
        }

        private void btnHastaIslemleri_Click(object sender, EventArgs e)
        {
            FrmHastaKayit fr = new FrmHastaKayit();
            fr.Show();
        }

        private void btnRandevu_Click(object sender, EventArgs e)
        {
            FrmRandevu fr = new FrmRandevu();
            fr.Show();
        }

        private void btnDoktorPanel_Click(object sender, EventArgs e)
        {
            FrmDoktorDetay fr = new FrmDoktorDetay();
            fr.doktorTC = tcKimlikNo;
            fr.Show();
        }
        private void btnRaporlar_Click(object sender, EventArgs e)
        {
            FrmRaporlar fr = new FrmRaporlar();
            fr.Show();
        }

        private void FrmAnaMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (cikisYapiliyor == false)
            {
                Application.Exit();
            }
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            cikisYapiliyor = true;
            FrmLogin fr = new FrmLogin();
            fr.Show();
            this.Close();
        }
    }
}
