﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmRandevu : Form
    {
        public FrmRandevu()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();

        private void FrmRandevu_Load(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM \"iller\".\"Iller\" ORDER BY \"ilAdi\"";
            using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
            {
                NpgsqlDataReader dr = komut.ExecuteReader();
                while (dr.Read())
                {
                    cmbSehir.Items.Add(dr["ilAdi"]);
                }
            }
            RandevuListele();
        }

        private void cmbSehir_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbHastane.Items.Clear();
            cmbPoliklinik.Items.Clear();
            cmbDoktor.Items.Clear();

            string sql = @"
                SELECT ""hastaneAdi"" FROM ""iller"".""Hastane"" 
                WHERE ""ilPlaka"" = (SELECT ""ilPlaka"" FROM ""iller"".""Iller"" WHERE ""ilAdi""=@p1)";

            using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
            {
                komut.Parameters.AddWithValue("@p1", cmbSehir.Text);
                NpgsqlDataReader dr = komut.ExecuteReader();
                while (dr.Read())
                {
                    cmbHastane.Items.Add(dr["hastaneAdi"]);
                }
            }
        }

        private void cmbHastane_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbPoliklinik.Items.Clear();
            cmbDoktor.Items.Clear();

            //seçilen hastanedeki mevcut poliklinikleri getir. poliklinik tablosu ile tür Tablosunu JOIN yapıyoruz
            string sql = @"
                SELECT t.""turAdi"" 
                FROM ""iller"".""Poliklinik"" p
                JOIN ""iller"".""PoliklinikTuru"" t ON p.""turId"" = t.""turId""
                WHERE p.""hastaneId"" = (SELECT ""hastaneId"" FROM ""iller"".""Hastane"" WHERE ""hastaneAdi""=@p1)";

            using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
            {
                komut.Parameters.AddWithValue("@p1", cmbHastane.Text);
                NpgsqlDataReader dr = komut.ExecuteReader();
                while (dr.Read())
                {
                    cmbPoliklinik.Items.Add(dr["turAdi"]);
                }
            }
        }

        private void cmbPoliklinik_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbDoktor.Items.Clear();

            string sql = @"
                SELECT v.""ad"", v.""soyad""
                FROM ""vatandas"".""Doktor"" d
                JOIN ""vatandas"".""Vatandas"" v ON d.""doktorId"" = v.""vatandasId""
                JOIN ""vatandas"".""HastanePersonel"" hp ON d.""doktorId"" = hp.""personelId""
                WHERE d.""uzmanlikAlani"" = @pPoliklinik 
                AND hp.""hastaneId"" = (SELECT ""hastaneId"" FROM ""iller"".""Hastane"" WHERE ""hastaneAdi""=@pHastane)";

            using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
            {
                komut.Parameters.AddWithValue("@pPoliklinik", cmbPoliklinik.Text);
                komut.Parameters.AddWithValue("@pHastane", cmbHastane.Text);

                NpgsqlDataReader dr = komut.ExecuteReader();
                while (dr.Read())
                {
                    cmbDoktor.Items.Add(dr["ad"] + " " + dr["soyad"]);
                }
            }
        }

        private void btnRandevuAl_Click(object sender, EventArgs e)
        {
            if (mskTC.Text.Length < 11 || cmbDoktor.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz.", "Eksik", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (NpgsqlConnection baglanti = bgl.Baglanti())
                {

                    // hasta ID tc'den bulunuyor
                    long tc = long.Parse(mskTC.Text);
                    int hastaId = 0;

                    string sqlHastaKontrol = @"SELECT v.""vatandasId"" 
                                       FROM ""vatandas"".""Vatandas"" v
                                       JOIN ""vatandas"".""Hasta"" h ON v.""vatandasId"" = h.""hastaId""
                                       WHERE v.""tcKimlikNo"" = @p1";

                    NpgsqlCommand cmdHasta = new NpgsqlCommand(sqlHastaKontrol, baglanti);
                    cmdHasta.Parameters.AddWithValue("@p1", tc);

                    object sonucHasta = cmdHasta.ExecuteScalar();

                    if (sonucHasta == null)
                    {
                        MessageBox.Show("Bu TC ile kayıtlı bir HASTA bulunamadı! \nLütfen önce 'Hasta Kayıt' ekranından kayıt açınız.", "Kayıt Yok", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // İşlemi durdur
                    }

                    hastaId = (int)sonucHasta;

                    // doktor ID ad soyadla bulunuyor
                    string[] adSoyad = cmbDoktor.Text.Split(' ');
                    string drAd = adSoyad[0];

                    int doktorId = 0;
                    string sqlDr = @"SELECT v.""vatandasId"" FROM ""vatandas"".""Vatandas"" v 
                             JOIN ""vatandas"".""Doktor"" d ON v.""vatandasId"" = d.""doktorId""
                             WHERE v.""ad""=@p1 LIMIT 1";
                    NpgsqlCommand cmdDr = new NpgsqlCommand(sqlDr, baglanti);
                    cmdDr.Parameters.AddWithValue("@p1", drAd);
                    doktorId = (int)cmdDr.ExecuteScalar();

                    // poliklinik id
                    int polId = 0;
                    string sqlPol = @"SELECT p.""poliklinikId"" FROM ""iller"".""Poliklinik"" p
                              JOIN ""iller"".""Hastane"" h ON p.""hastaneId"" = h.""hastaneId""
                              JOIN ""iller"".""PoliklinikTuru"" t ON p.""turId"" = t.""turId""
                              WHERE h.""hastaneAdi""=@p1 AND t.""turAdi""=@p2 LIMIT 1";
                    NpgsqlCommand cmdPol = new NpgsqlCommand(sqlPol, baglanti);
                    cmdPol.Parameters.AddWithValue("@p1", cmbHastane.Text);
                    cmdPol.Parameters.AddWithValue("@p2", cmbPoliklinik.Text);
                    polId = (int)cmdPol.ExecuteScalar();

                    //randevu ekleme işlemi
                    string sqlInsert = @"INSERT INTO ""randevular"".""Randevu"" 
                               (""hastaId"", ""doktorId"", ""poliklinikId"", ""randevuTarihi"")
                               VALUES (@h, @d, @p, @t)";

                    NpgsqlCommand komut = new NpgsqlCommand(sqlInsert, baglanti);
                    komut.Parameters.AddWithValue("@h", hastaId);
                    komut.Parameters.AddWithValue("@d", doktorId);
                    komut.Parameters.AddWithValue("@p", polId);
                    komut.Parameters.AddWithValue("@t", dtpTarih.Value);

                    komut.ExecuteNonQuery();

                    MessageBox.Show("Randevu Başarıyla Oluşturuldu!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    RandevuListele();
                }
            }
            catch (NpgsqlException ex)
            {
                // PostgreSQL hata kodu 23505: Unique Constraint (Tekillik İhlali) demektir
                if (ex.SqlState == "23505")
                {
                    MessageBox.Show("Seçilen tarih ve saatte bu doktorun zaten bir randevusu mevcut! \nLütfen başka bir tarih veya saat seçiniz.",
                                    "Randevu Dolu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (ex.Message.Contains("HATA:"))
                {
                    MessageBox.Show(ex.Message, "Sistem Uyarısı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MessageBox.Show("Veritabanı Hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Genel Hata: " + ex.Message);
            }
        }

        private void btnRandevuIptal_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Lütfen iptal edilecek randevuyu seçiniz.");
                return;
            }
            DialogResult secim = MessageBox.Show("Seçili randevuyu iptal etmek istediğinize emin misiniz?\nBu işlem geri alınamaz ve log kaydı oluşturulacaktır.",
                                                 "Randevu İptal", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (secim == DialogResult.Yes)
            {
                int secilenRandevuId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["randevuId"].Value);

                SqlBaglantisi bgl = new SqlBaglantisi();

                NpgsqlConnection baglan = bgl.Baglanti();

                try
                {
                    NpgsqlCommand komut = new NpgsqlCommand("DELETE FROM \"randevular\".\"Randevu\" WHERE \"randevuId\"=@p1", baglan);

                    komut.Parameters.AddWithValue("@p1", secilenRandevuId);
                    komut.ExecuteNonQuery();

                    MessageBox.Show("Randevu iptal edildi. \n(Log Trigger'ı çalıştı ve kayıt 'RandevuIptalLog' tablosuna eklendi.)", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    RandevuListele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                }
                finally
                {
                    baglan.Close();
                }
            }
        }
        void RandevuListele()
        {
            SqlBaglantisi bgl = new SqlBaglantisi();
            NpgsqlConnection conn = bgl.Baglanti();

            try
            {
                string sql = @"
            SELECT 
                r.""randevuId"",
                r.""randevuTarihi"" as ""Tarih"",
                (v_h.""ad"" || ' ' || v_h.""soyad"") as ""Hasta Adı"",
                (v_d.""ad"" || ' ' || v_d.""soyad"") as ""Doktor Adı""
            FROM ""randevular"".""Randevu"" r
            INNER JOIN ""vatandas"".""Hasta"" h ON r.""hastaId"" = h.""hastaId""
            INNER JOIN ""vatandas"".""Vatandas"" v_h ON h.""hastaId"" = v_h.""vatandasId""
            INNER JOIN ""vatandas"".""Doktor"" d ON r.""doktorId"" = d.""doktorId""
            INNER JOIN ""vatandas"".""Vatandas"" v_d ON d.""doktorId"" = v_d.""vatandasId""
            ORDER BY r.""randevuTarihi"" DESC
        ";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                if (dataGridView1.Columns["randevuId"] != null)
                {
                    dataGridView1.Columns["randevuId"].Visible = false;
                }

                if (dataGridView1.Columns["Tarih"] != null)
                {
                    dataGridView1.Columns["Tarih"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Listeleme Hatası: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
