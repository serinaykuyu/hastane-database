﻿using Npgsql;
using System;
using System.Data;

namespace HastaneVeritabani
{
    public class SqlBaglantisi
    {
        private string connectionString = "Host=localhost;Username=postgres;Password=kumbara+02;Database=hastane";

        public NpgsqlConnection Baglanti()
        {
            NpgsqlConnection baglan = new NpgsqlConnection(connectionString);
            if (baglan.State != ConnectionState.Open)
            {
                baglan.Open();
            }
            return baglan;
        }
    }
}