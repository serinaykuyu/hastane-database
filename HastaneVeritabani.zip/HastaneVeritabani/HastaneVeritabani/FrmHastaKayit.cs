﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmHastaKayit : Form
    {
        public FrmHastaKayit()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();

        void Listele()
        {
            string sql = @"
                SELECT v.""tcKimlikNo"", v.""ad"", v.""soyad"", v.""adres"", h.""sigortaTuru""
                FROM ""vatandas"".""Vatandas"" v
                JOIN ""vatandas"".""Hasta"" h ON v.""vatandasId"" = h.""hastaId""
            ";

            DataTable dt = new DataTable();
            using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, bgl.Baglanti()))
            {
                da.Fill(dt);
            }
            dataGridView1.DataSource = dt;
        }

        private void FrmHastaKayit_Load(object sender, EventArgs e)
        {
            Listele();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlVatandas = @"
                    INSERT INTO ""vatandas"".""Vatandas"" (""tcKimlikNo"", ""ad"", ""soyad"", ""adres"") 
                    VALUES (@p1, @p2, @p3, @p4) RETURNING ""vatandasId"";
                ";

                using (NpgsqlConnection baglanti = bgl.Baglanti())
                {
                    NpgsqlCommand komut1 = new NpgsqlCommand(sqlVatandas, baglanti);
                    komut1.Parameters.AddWithValue("@p1", long.Parse(mskTC.Text));
                    komut1.Parameters.AddWithValue("@p2", txtAd.Text);
                    komut1.Parameters.AddWithValue("@p3", txtSoyad.Text);
                    komut1.Parameters.AddWithValue("@p4", txtAdres.Text);

                    int yeniId = (int)komut1.ExecuteScalar();

                    string sqlHasta = @"
                        INSERT INTO ""vatandas"".""Hasta"" (""hastaId"", ""sigortaTuru"") 
                        VALUES (@p1, @p2)";

                    NpgsqlCommand komut2 = new NpgsqlCommand(sqlHasta, baglanti);
                    komut2.Parameters.AddWithValue("@p1", yeniId); 
                    komut2.Parameters.AddWithValue("@p2", cmbSigorta.Text);
                    komut2.ExecuteNonQuery();

                    MessageBox.Show("Hasta kaydı başarıyla oluşturuldu.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Listele(); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "DELETE FROM \"vatandas\".\"Vatandas\" WHERE \"tcKimlikNo\"=@p1";

                using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
                {
                    komut.Parameters.AddWithValue("@p1", long.Parse(mskTC.Text));
                    komut.ExecuteNonQuery();

                    MessageBox.Show("Hasta kaydı silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Listele();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            try
            {

                string sql = @"
                    UPDATE ""vatandas"".""Vatandas"" SET ""ad""=@p1, ""soyad""=@p2, ""adres""=@p3 WHERE ""tcKimlikNo""=@p4;
                    
                    UPDATE ""vatandas"".""Hasta"" SET ""sigortaTuru""=@p5 
                    WHERE ""hastaId"" = (SELECT ""vatandasId"" FROM ""vatandas"".""Vatandas"" WHERE ""tcKimlikNo""=@p4);
                ";

                using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
                {
                    komut.Parameters.AddWithValue("@p1", txtAd.Text);
                    komut.Parameters.AddWithValue("@p2", txtSoyad.Text);
                    komut.Parameters.AddWithValue("@p3", txtAdres.Text);
                    komut.Parameters.AddWithValue("@p4", long.Parse(mskTC.Text));
                    komut.Parameters.AddWithValue("@p5", cmbSigorta.Text);

                    komut.ExecuteNonQuery();

                    MessageBox.Show("Bilgiler güncellendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Listele();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            mskTC.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            txtSoyad.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            txtAdres.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            cmbSigorta.Text = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }
    }
}
