﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmHastaKayit : Form
    {

        long secilenHastaTC = 0;

        public FrmHastaKayit()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();

        void Listele()
        {
            string sql = @"
                SELECT v.""tcKimlikNo"", v.""ad"", v.""soyad"", v.""adres"", h.""sigortaTuru""
                FROM ""vatandas"".""Vatandas"" v
                JOIN ""vatandas"".""Hasta"" h ON v.""vatandasId"" = h.""hastaId""
            ";

            DataTable dt = new DataTable();
            using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, bgl.Baglanti()))
            {
                da.Fill(dt);
            }
            dataGridView1.DataSource = dt;
        }

        private void FrmHastaKayit_Load(object sender, EventArgs e)
        {
            Listele();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlVatandas = @"
                    INSERT INTO ""vatandas"".""Vatandas"" (""tcKimlikNo"", ""ad"", ""soyad"", ""adres"") 
                    VALUES (@p1, @p2, @p3, @p4) RETURNING ""vatandasId"";
                ";

                using (NpgsqlConnection baglanti = bgl.Baglanti())
                {
                    NpgsqlCommand komut1 = new NpgsqlCommand(sqlVatandas, baglanti);
                    komut1.Parameters.AddWithValue("@p1", long.Parse(mskTC.Text));
                    komut1.Parameters.AddWithValue("@p2", txtAd.Text);
                    komut1.Parameters.AddWithValue("@p3", txtSoyad.Text);
                    komut1.Parameters.AddWithValue("@p4", txtAdres.Text);

                    int yeniId = (int)komut1.ExecuteScalar();

                    string sqlHasta = @"
                        INSERT INTO ""vatandas"".""Hasta"" (""hastaId"", ""sigortaTuru"") 
                        VALUES (@p1, @p2)";

                    NpgsqlCommand komut2 = new NpgsqlCommand(sqlHasta, baglanti);
                    komut2.Parameters.AddWithValue("@p1", yeniId); 
                    komut2.Parameters.AddWithValue("@p2", cmbSigorta.Text);
                    komut2.ExecuteNonQuery();

                    MessageBox.Show("Hasta kaydı başarıyla oluşturuldu.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Listele(); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "DELETE FROM \"vatandas\".\"Vatandas\" WHERE \"tcKimlikNo\"=@p1";

                using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
                {
                    komut.Parameters.AddWithValue("@p1", long.Parse(mskTC.Text));
                    komut.ExecuteNonQuery();

                    MessageBox.Show("Hasta kaydı silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Listele();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (secilenHastaTC == 0)
            {
                MessageBox.Show("Lütfen önce listeden güncellenecek hastayı seçiniz.");
                return;
            }

            try
            {
                string sql = @"
            UPDATE ""vatandas"".""Vatandas"" 
            SET ""ad""=@p1, ""soyad""=@p2, ""adres""=@p3, ""tcKimlikNo""=@yeniTC
            WHERE ""tcKimlikNo""=@orjinalTC;
            
            UPDATE ""vatandas"".""Hasta"" 
            SET ""sigortaTuru""=@p5 
            WHERE ""hastaId"" = (SELECT ""vatandasId"" FROM ""vatandas"".""Vatandas"" WHERE ""tcKimlikNo""=@yeniTC);
        ";

                var baglanti = bgl.Baglanti();
                using (NpgsqlCommand komut = new NpgsqlCommand(sql, baglanti))
                {
                    komut.Parameters.AddWithValue("@p1", txtAd.Text);
                    komut.Parameters.AddWithValue("@p2", txtSoyad.Text);
                    komut.Parameters.AddWithValue("@p3", txtAdres.Text);

                    komut.Parameters.AddWithValue("@yeniTC", long.Parse(mskTC.Text));

                    komut.Parameters.AddWithValue("@orjinalTC", secilenHastaTC);

                    if (cmbSigorta.SelectedItem != null)
                        komut.Parameters.AddWithValue("@p5", cmbSigorta.Text);
                    else
                        komut.Parameters.AddWithValue("@p5", DBNull.Value);

                    int sonuc = komut.ExecuteNonQuery();
                    baglanti.Close();

                    if (sonuc > 0)
                    {
                        MessageBox.Show("Bilgiler güncellendi.");
                        Listele();

                        secilenHastaTC = long.Parse(mskTC.Text);
                    }
                    else
                    {
                        MessageBox.Show("Hata: Kayıt bulunamadı. Lütfen listeyi yenileyip tekrar deneyin.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtAd.Text = row.Cells["ad"].Value.ToString();
                txtSoyad.Text = row.Cells["soyad"].Value.ToString();
                mskTC.Text = row.Cells["tcKimlikNo"].Value.ToString();
                txtAdres.Text = row.Cells["adres"].Value.ToString();
                cmbSigorta.Text = row.Cells["sigortaTuru"].Value.ToString();

                long.TryParse(row.Cells["tcKimlikNo"].Value.ToString(), out secilenHastaTC);
            }
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            Listele();
        }
    }
}
