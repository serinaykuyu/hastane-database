﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();

        private void btnGiris_Click(object sender, EventArgs e)
        {
            if (txtTC.Text == "" || txtSifre.Text == "")
            {
                MessageBox.Show("Lütfen TC ve Şifre giriniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string sql = @"
                    SELECT p.""gorevTuru"", v.""ad"", v.""soyad""
                    FROM ""vatandas"".""Personel"" p
                    JOIN ""vatandas"".""Vatandas"" v ON p.""personelId"" = v.""vatandasId""
                    WHERE v.""tcKimlikNo"" = @p1 AND p.""sifre"" = @p2";

                using (NpgsqlCommand komut = new NpgsqlCommand(sql, bgl.Baglanti()))
                {
                    komut.Parameters.AddWithValue("@p1", long.Parse(txtTC.Text));
                    komut.Parameters.AddWithValue("@p2", txtSifre.Text);

                    NpgsqlDataReader dr = komut.ExecuteReader();

                    if (dr.Read())
                    {
                        string adSoyad = dr["ad"].ToString() + " " + dr["soyad"].ToString();
                        string gorev = dr["gorevTuru"].ToString();

                        FrmAnaMenu fr = new FrmAnaMenu();
                        fr.tcKimlikNo = txtTC.Text;
                        fr.adSoyad = adSoyad;
                        fr.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Hatalı TC Kimlik No veya Şifre!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("TC Kimlik No sadece rakamlardan oluşmalıdır.", "Format Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
        }

        private void FrmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
