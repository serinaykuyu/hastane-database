﻿namespace HastaneVeritabani
{
    partial class FrmDoktorDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDoktorDetay));
            lblTC = new Label();
            lblAdSoyad = new Label();
            groupBox1 = new GroupBox();
            gridRandevular = new DataGridView();
            groupBox2 = new GroupBox();
            btnTaburcu = new Button();
            label5 = new Label();
            cmbOdalar = new ComboBox();
            btnYatis = new Button();
            btnOdemeAl = new Button();
            label4 = new Label();
            txtHastaTC = new TextBox();
            btnGecmisGetir = new Button();
            btnKaydet = new Button();
            txtAdet = new TextBox();
            label3 = new Label();
            cmbIlac = new ComboBox();
            label2 = new Label();
            txtTani = new RichTextBox();
            label1 = new Label();
            panel1 = new Panel();
            groupBox3 = new GroupBox();
            hastaGecmisListe = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridRandevular).BeginInit();
            groupBox2.SuspendLayout();
            panel1.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)hastaGecmisListe).BeginInit();
            SuspendLayout();
            // 
            // lblTC
            // 
            lblTC.AutoSize = true;
            lblTC.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold);
            lblTC.ForeColor = SystemColors.Window;
            lblTC.Location = new Point(9, 6);
            lblTC.Name = "lblTC";
            lblTC.Size = new Size(52, 19);
            lblTC.TabIndex = 0;
            lblTC.Text = "lblTC";
            // 
            // lblAdSoyad
            // 
            lblAdSoyad.AutoSize = true;
            lblAdSoyad.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold);
            lblAdSoyad.ForeColor = SystemColors.Window;
            lblAdSoyad.Location = new Point(9, 25);
            lblAdSoyad.Name = "lblAdSoyad";
            lblAdSoyad.Size = new Size(55, 19);
            lblAdSoyad.TabIndex = 1;
            lblAdSoyad.Text = "label2";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(gridRandevular);
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(9, 75);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(562, 253);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Randevu Listesi:";
            // 
            // gridRandevular
            // 
            gridRandevular.BackgroundColor = SystemColors.Window;
            gridRandevular.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridRandevular.Location = new Point(6, 25);
            gridRandevular.Name = "gridRandevular";
            gridRandevular.Size = new Size(550, 222);
            gridRandevular.TabIndex = 0;
            gridRandevular.CellClick += gridRandevular_CellClick;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnTaburcu);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(cmbOdalar);
            groupBox2.Controls.Add(btnYatis);
            groupBox2.Controls.Add(btnOdemeAl);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(txtHastaTC);
            groupBox2.Controls.Add(btnGecmisGetir);
            groupBox2.Controls.Add(btnKaydet);
            groupBox2.Controls.Add(txtAdet);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(cmbIlac);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtTani);
            groupBox2.Controls.Add(label1);
            groupBox2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.Location = new Point(577, 75);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(348, 504);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Muayene Paneli";
            // 
            // btnTaburcu
            // 
            btnTaburcu.Location = new Point(15, 377);
            btnTaburcu.Name = "btnTaburcu";
            btnTaburcu.Size = new Size(152, 35);
            btnTaburcu.TabIndex = 14;
            btnTaburcu.Text = "Taburcu Et";
            btnTaburcu.UseVisualStyleBackColor = true;
            btnTaburcu.Click += btnTaburcu_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(15, 347);
            label5.Name = "label5";
            label5.Size = new Size(157, 19);
            label5.TabIndex = 13;
            label5.Text = "Yatış İçin Oda Seçiniz:";
            // 
            // cmbOdalar
            // 
            cmbOdalar.FormattingEnabled = true;
            cmbOdalar.Location = new Point(179, 344);
            cmbOdalar.Name = "cmbOdalar";
            cmbOdalar.Size = new Size(152, 27);
            cmbOdalar.TabIndex = 12;
            // 
            // btnYatis
            // 
            btnYatis.Location = new Point(179, 377);
            btnYatis.Name = "btnYatis";
            btnYatis.Size = new Size(152, 35);
            btnYatis.TabIndex = 11;
            btnYatis.Text = "Yatış Gerçekleştir";
            btnYatis.UseVisualStyleBackColor = true;
            btnYatis.Click += btnYatis_Click;
            // 
            // btnOdemeAl
            // 
            btnOdemeAl.Location = new Point(226, 294);
            btnOdemeAl.Name = "btnOdemeAl";
            btnOdemeAl.Size = new Size(105, 35);
            btnOdemeAl.TabIndex = 10;
            btnOdemeAl.Text = "Ödeme Al";
            btnOdemeAl.UseVisualStyleBackColor = true;
            btnOdemeAl.Click += btnOdemeAl_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 434);
            label4.Name = "label4";
            label4.Size = new Size(79, 19);
            label4.TabIndex = 9;
            label4.Text = "Hasta TC:";
            // 
            // txtHastaTC
            // 
            txtHastaTC.Location = new Point(100, 431);
            txtHastaTC.MaxLength = 11;
            txtHastaTC.Name = "txtHastaTC";
            txtHastaTC.Size = new Size(231, 26);
            txtHastaTC.TabIndex = 8;
            // 
            // btnGecmisGetir
            // 
            btnGecmisGetir.Location = new Point(15, 463);
            btnGecmisGetir.Name = "btnGecmisGetir";
            btnGecmisGetir.Size = new Size(316, 35);
            btnGecmisGetir.TabIndex = 7;
            btnGecmisGetir.Text = "Hasta Geçmişi Getir";
            btnGecmisGetir.UseVisualStyleBackColor = true;
            btnGecmisGetir.Click += btnGecmisGetir_Click;
            // 
            // btnKaydet
            // 
            btnKaydet.BackColor = Color.White;
            btnKaydet.Location = new Point(15, 294);
            btnKaydet.Name = "btnKaydet";
            btnKaydet.Size = new Size(205, 35);
            btnKaydet.TabIndex = 6;
            btnKaydet.Text = "Muayene Et ve Reçete Yaz";
            btnKaydet.UseCompatibleTextRendering = true;
            btnKaydet.UseVisualStyleBackColor = false;
            btnKaydet.Click += btnKaydet_Click;
            // 
            // txtAdet
            // 
            txtAdet.Location = new Point(88, 256);
            txtAdet.Name = "txtAdet";
            txtAdet.Size = new Size(119, 26);
            txtAdet.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold);
            label3.Location = new Point(33, 259);
            label3.Name = "label3";
            label3.Size = new Size(49, 19);
            label3.TabIndex = 4;
            label3.Text = "Adet:";
            // 
            // cmbIlac
            // 
            cmbIlac.FormattingEnabled = true;
            cmbIlac.Location = new Point(88, 216);
            cmbIlac.Name = "cmbIlac";
            cmbIlac.Size = new Size(243, 27);
            cmbIlac.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold);
            label2.Location = new Point(10, 219);
            label2.Name = "label2";
            label2.Size = new Size(72, 19);
            label2.TabIndex = 2;
            label2.Text = "İlaç Seç:";
            // 
            // txtTani
            // 
            txtTani.Location = new Point(15, 55);
            txtTani.Name = "txtTani";
            txtTani.Size = new Size(316, 141);
            txtTani.TabIndex = 1;
            txtTani.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(15, 33);
            label1.Name = "label1";
            label1.Size = new Size(113, 19);
            label1.TabIndex = 0;
            label1.Text = "Şikayet / Tanı:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.Controls.Add(lblAdSoyad);
            panel1.Controls.Add(lblTC);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(936, 51);
            panel1.TabIndex = 4;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(hastaGecmisListe);
            groupBox3.Location = new Point(9, 334);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(562, 245);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "Hasta Geçmişi:";
            // 
            // hastaGecmisListe
            // 
            hastaGecmisListe.BackgroundColor = SystemColors.Window;
            hastaGecmisListe.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            hastaGecmisListe.Location = new Point(6, 24);
            hastaGecmisListe.Name = "hastaGecmisListe";
            hastaGecmisListe.Size = new Size(550, 215);
            hastaGecmisListe.TabIndex = 0;
            // 
            // FrmDoktorDetay
            // 
            AutoScaleDimensions = new SizeF(9F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(936, 592);
            Controls.Add(groupBox3);
            Controls.Add(panel1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "FrmDoktorDetay";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Doktor Detay";
            Load += FrmDoktorDetay_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridRandevular).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)hastaGecmisListe).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblTC;
        private Label lblAdSoyad;
        private GroupBox groupBox1;
        private DataGridView gridRandevular;
        private GroupBox groupBox2;
        private Label label2;
        private RichTextBox txtTani;
        private Label label1;
        private TextBox txtAdet;
        private Label label3;
        private ComboBox cmbIlac;
        private Button btnKaydet;
        private Panel panel1;
        private Button btnGecmisGetir;
        private GroupBox groupBox3;
        private DataGridView hastaGecmisListe;
        private Label label4;
        private TextBox txtHastaTC;
        private Button btnOdemeAl;
        private Button btnYatis;
        private ComboBox cmbOdalar;
        private Label label5;
        private Button btnTaburcu;
    }
}