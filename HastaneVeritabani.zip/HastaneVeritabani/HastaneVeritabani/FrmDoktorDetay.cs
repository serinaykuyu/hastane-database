﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmDoktorDetay : Form
    {
        public FrmDoktorDetay()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();
        public string doktorTC; // ana menüden gelen TC
        int doktorHastaneId = 0;
        int doktorId = 0;       // TC'den bulacağımız ID
        int secilenRandevuId = 0;
        int secilenHastaId = 0;

        private void FrmDoktorDetay_Load(object sender, EventArgs e)
        {
            lblTC.Text = doktorTC;

            using (NpgsqlConnection baglan = bgl.Baglanti())
            {

                string sqlDoktorBilgi = @"
                SELECT hp.""hastaneId"" 
                FROM ""vatandas"".""HastanePersonel"" hp
                INNER JOIN ""vatandas"".""Personel"" p ON hp.""personelId"" = p.""personelId""
                INNER JOIN ""vatandas"".""Vatandas"" v ON p.""personelId"" = v.""vatandasId""
                WHERE v.""tcKimlikNo"" = @tc";

                NpgsqlCommand kmt = new NpgsqlCommand(sqlDoktorBilgi, baglan);
                kmt.Parameters.AddWithValue("@tc", long.Parse(doktorTC));

                object sonuc = kmt.ExecuteScalar();
                if (sonuc != null)
                {
                    doktorHastaneId = Convert.ToInt32(sonuc);
                }
            }

            using (NpgsqlConnection baglan = bgl.Baglanti())
            {
                string sqlOdalar = "SELECT \"odaNo\" FROM \"iller\".\"Oda\" WHERE \"hastaneId\" = @hid";
                NpgsqlCommand kmtOda = new NpgsqlCommand(sqlOdalar, baglan);
                kmtOda.Parameters.AddWithValue("@hid", doktorHastaneId);

                NpgsqlDataReader dr = kmtOda.ExecuteReader();
                while (dr.Read())
                {
                    cmbOdalar.Items.Add(dr[0].ToString());
                }
            }

            using (NpgsqlConnection baglanti = bgl.Baglanti())
            {
                // TC'den doktor ID ve ad soyad buluyoruz
                string sqlDr = @"SELECT v.""ad"", v.""soyad"", d.""doktorId"" 
                                 FROM ""vatandas"".""Vatandas"" v
                                 JOIN ""vatandas"".""Doktor"" d ON v.""vatandasId"" = d.""doktorId""
                                 WHERE v.""tcKimlikNo"" = @p1";

                NpgsqlCommand komut = new NpgsqlCommand(sqlDr, baglanti);
                komut.Parameters.AddWithValue("@p1", long.Parse(doktorTC));
                NpgsqlDataReader dr = komut.ExecuteReader();
                if (dr.Read())
                {
                    lblAdSoyad.Text = dr["ad"] + " " + dr["soyad"];
                    doktorId = int.Parse(dr["doktorId"].ToString());
                }
                dr.Close();

                NpgsqlCommand cmdIlac = new NpgsqlCommand("SELECT \"ilacAdi\" FROM \"randevular\".\"Ilaclar\"", baglanti);
                NpgsqlDataReader drIlac = cmdIlac.ExecuteReader();
                while (drIlac.Read())
                {
                    cmbIlac.Items.Add(drIlac[0].ToString());
                }
            }

            RandevuListele();
        }
        void RandevuListele()
        {
            string sql = @"
            SELECT r.""randevuId"", r.""hastaId"", r.""randevuTarihi"", v.""ad"", v.""soyad"", v.""tcKimlikNo""
            FROM ""randevular"".""Randevu"" r
            JOIN ""vatandas"".""Vatandas"" v ON r.""hastaId"" = v.""vatandasId""
            WHERE r.""doktorId"" = @p1 
            AND r.""randevuId"" NOT IN (SELECT ""randevuId"" FROM ""randevular"".""Muayene"")";

            DataTable dt = new DataTable();
            using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, bgl.Baglanti()))
            {
                da.SelectCommand.Parameters.AddWithValue("@p1", doktorId);
                da.Fill(dt);
            }
            gridRandevular.DataSource = dt;
        }

        private void gridRandevular_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = gridRandevular.SelectedCells[0].RowIndex;
            secilenRandevuId = int.Parse(gridRandevular.Rows[secilen].Cells["randevuId"].Value.ToString());

            string ad = gridRandevular.Rows[secilen].Cells["ad"].Value.ToString();
            string soyad = gridRandevular.Rows[secilen].Cells["soyad"].Value.ToString();
            this.Text = "Seçilen Hasta: " + ad + " " + soyad;

            secilenHastaId = int.Parse(gridRandevular.Rows[secilen].Cells["hastaId"].Value.ToString());

            long hTC = long.Parse(gridRandevular.Rows[secilen].Cells["tcKimlikNo"].Value.ToString());
            using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT \"vatandasId\" FROM \"vatandas\".\"Vatandas\" WHERE \"tcKimlikNo\"=@p1", bgl.Baglanti()))
            {
                cmd.Parameters.AddWithValue("@p1", hTC);
                secilenHastaId = (int)cmd.ExecuteScalar();
            }
        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (secilenRandevuId == 0) { MessageBox.Show("Lütfen listeden bir hasta seçin!"); return; }

            using (NpgsqlConnection baglanti = bgl.Baglanti())
            {

                NpgsqlTransaction islem = baglanti.BeginTransaction();

                try
                {

                    string sqlMuayene = @"INSERT INTO ""randevular"".""Muayene"" (""randevuId"", ""tani"", ""muayeneSonuc"") 
                                  VALUES (@p1, @p2, @p3) RETURNING ""muayeneId""";

                    NpgsqlCommand cmd1 = new NpgsqlCommand(sqlMuayene, baglanti);
                    cmd1.Transaction = islem;
                    cmd1.Parameters.AddWithValue("@p1", secilenRandevuId);
                    cmd1.Parameters.AddWithValue("@p2", txtTani.Text);
                    cmd1.Parameters.AddWithValue("@p3", "Reçete Verildi");
                    int muayeneId = (int)cmd1.ExecuteScalar();

                    string sqlRecete = @"INSERT INTO ""randevular"".""Recete"" (""muayeneId"", ""doktorId"", ""hastaId"", ""receteTarihi"")
                                 VALUES (@p1, @p2, @p3, @p4) RETURNING ""receteId""";

                    NpgsqlCommand cmd2 = new NpgsqlCommand(sqlRecete, baglanti);
                    cmd2.Transaction = islem;
                    cmd2.Parameters.AddWithValue("@p1", muayeneId);
                    cmd2.Parameters.AddWithValue("@p2", doktorId);
                    cmd2.Parameters.AddWithValue("@p3", secilenHastaId);
                    cmd2.Parameters.AddWithValue("@p4", DateTime.Now);
                    int receteId = (int)cmd2.ExecuteScalar();

                    long ilacId = 0;
                    NpgsqlCommand cmdIlacBul = new NpgsqlCommand("SELECT \"barkod\" FROM \"randevular\".\"Ilaclar\" WHERE \"ilacAdi\"=@p1", baglanti);
                    cmdIlacBul.Transaction = islem;
                    cmdIlacBul.Parameters.AddWithValue("@p1", cmbIlac.Text);
                    object sonucIlac = cmdIlacBul.ExecuteScalar();

                    if (sonucIlac == null) throw new Exception("Seçilen ilaç veritabanında bulunamadı!");
                    ilacId = (long)sonucIlac;

                    string sqlDetay = @"INSERT INTO ""randevular"".""ReceteDetay"" (""receteId"", ""ilacId"", ""kullanimDozu"", ""adet"")
                                VALUES (@p1, @p2, @p3, @p4)";

                    NpgsqlCommand cmd3 = new NpgsqlCommand(sqlDetay, baglanti);
                    cmd3.Transaction = islem;
                    cmd3.Parameters.AddWithValue("@p1", receteId);
                    cmd3.Parameters.AddWithValue("@p2", ilacId);
                    cmd3.Parameters.AddWithValue("@p3", "1x1 Tok");

                    int adet = 0;
                    int.TryParse(txtAdet.Text, out adet);
                    cmd3.Parameters.AddWithValue("@p4", adet);

                    cmd3.ExecuteNonQuery();

                    islem.Commit();
                    MessageBox.Show("Muayene ve Reçete Başarıyla Kaydedildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtTani.Clear();
                    txtAdet.Clear();
                    secilenRandevuId = 0;
                    RandevuListele();
                }
                catch (Exception ex)
                {
                    islem.Rollback();

                    if (ex.Message.Contains("HATA:"))
                    {
                        MessageBox.Show(ex.Message, "Sistem Uyarısı", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                    else
                    {
                        MessageBox.Show("İşlem Başarısız: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnGecmisGetir_Click(object sender, EventArgs e)
        {
            using NpgsqlConnection baglanti = new NpgsqlConnection("Host=localhost;Port=5432;Database=hastane;Username=postgres;Password=kumbara+02");

            try
            {
                baglanti.Open();
                string sql = "SELECT * FROM \"randevular\".\"fn_HastaGecmisi\"(@tc)";

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, baglanti);

                da.SelectCommand.Parameters.AddWithValue("@tc", long.Parse(txtHastaTC.Text));

                DataTable dt = new DataTable();
                da.Fill(dt);

                hastaGecmisListe.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void btnOdemeAl_Click(object sender, EventArgs e)
        {
            if (gridRandevular.CurrentRow == null)
            {
                MessageBox.Show("Lütfen ödeme alınacak randevuyu seçiniz.");
                return;
            }

            int secilenId = Convert.ToInt32(gridRandevular.CurrentRow.Cells["randevuId"].Value);

            decimal tutar = 500.00m;

            SqlBaglantisi bgl = new SqlBaglantisi();

            using (NpgsqlConnection baglan = bgl.Baglanti())
            {
                try
                {
                    string sql = @"INSERT INTO ""randevular"".""Odeme"" 
                           (""randevuId"", ""muayeneId"", ""veznedarId"", ""tutar"") 
                           VALUES 
                           (@rid, @mid, 1, @tutar)";

                    NpgsqlCommand cmd = new NpgsqlCommand(sql, baglan);
                    cmd.Parameters.AddWithValue("@rid", secilenRandevuId);
                    cmd.Parameters.AddWithValue("@mid", DBNull.Value);
                    cmd.Parameters.AddWithValue("@tutar", tutar);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Ödeme başarıyla alındı.\n(Trigger çalıştı, hastane cirosu güncellendi.)", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message);
                }
            }
        }

        private void btnYatis_Click(object sender, EventArgs e)
        {
            if (gridRandevular.CurrentRow == null)
            {
                MessageBox.Show("Lütfen yatış verilecek hastayı (randevuyu) seçiniz.");
                return;
            }

            if (cmbOdalar.Text == "")
            {
                MessageBox.Show("Lütfen bir oda seçiniz.");
                return;
            }
            int secilenHastaId = Convert.ToInt32(gridRandevular.CurrentRow.Cells["hastaId"].Value);

            try
            {
                using (NpgsqlConnection baglan = bgl.Baglanti())
                {
                    string sql = @"INSERT INTO ""randevular"".""Yatis"" (""hastaId"", ""hastaneId"", ""odaNo"") 
                           VALUES (@p1, @p2, @p3)";

                    NpgsqlCommand komut = new NpgsqlCommand(sql, baglan);
                    komut.Parameters.AddWithValue("@p1", secilenHastaId);
                    komut.Parameters.AddWithValue("@p2", doktorHastaneId);
                    komut.Parameters.AddWithValue("@p3", cmbOdalar.Text);

                    komut.ExecuteNonQuery();

                    MessageBox.Show("Hasta yatışı başarıyla yapıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (PostgresException ex)
            {
                MessageBox.Show("YATIŞ İŞLEMİ BAŞARISIZ!\n\nVeritabanı Mesajı: " + ex.MessageText, "Kapasite Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Genel Hata: " + ex.Message);
            }

        }

        private void btnTaburcu_Click(object sender, EventArgs e)
        {
            if (gridRandevular.CurrentRow == null)
            {
                MessageBox.Show("Lütfen taburcu edilecek hastayı seçiniz.");
                return;
            }

            DialogResult secim = MessageBox.Show(
            "Seçilen hastanın taburcu işlemini onaylıyor musunuz?\n(Oda kapasitesi boşa çıkacaktır)",
            "Taburcu Onayı",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

            if (secim == DialogResult.No) return;

            try
            {
                int secilenHastaId = Convert.ToInt32(gridRandevular.CurrentRow.Cells["hastaId"].Value);

                using (NpgsqlConnection baglan = bgl.Baglanti())
                {
                    string sql = @"
                    UPDATE ""randevular"".""Yatis"" 
                    SET ""taburcuTarihi"" = CURRENT_DATE 
                    WHERE ""hastaId"" = @p1 AND ""taburcuTarihi"" IS NULL";

                    NpgsqlCommand komut = new NpgsqlCommand(sql, baglan);
                    komut.Parameters.AddWithValue("@p1", secilenHastaId);

                    int sonuc = komut.ExecuteNonQuery();

                    if (sonuc > 0)
                    {
                        MessageBox.Show("Hasta başarıyla taburcu edildi.\nOda yatağı boşa çıkarıldı.", "İşlem Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        RandevuListele();
                    }
                    else
                    {
                        MessageBox.Show("Bu hasta şu an hastanede yatmıyor görünüyor.\n(Zaten taburcu edilmiş olabilir)", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata oluştu: " + ex.Message);
            }
        }
    }
}