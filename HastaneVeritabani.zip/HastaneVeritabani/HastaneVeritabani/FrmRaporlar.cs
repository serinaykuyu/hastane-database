﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HastaneVeritabani
{
    public partial class FrmRaporlar : Form
    {
        public FrmRaporlar()
        {
            InitializeComponent();
        }

        SqlBaglantisi bgl = new SqlBaglantisi();

        private void btnCiroHesapla_Click(object sender, EventArgs e)
        {
            try
            {
                using (NpgsqlConnection baglanti = bgl.Baglanti())
                {
                    string sql = "SELECT \"randevular\".\"fn_HastaneCiroHesapla\"(1)";

                    NpgsqlCommand komut = new NpgsqlCommand(sql, baglanti);
                    object sonuc = komut.ExecuteScalar();

                    if (sonuc != null)
                    {
                        lblCiro.Text = sonuc.ToString() + " TL";
                    }
                    else
                    {
                        lblCiro.Text = "0.00 TL";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hesaplama Hatası: " + ex.Message);
            }
        }

        private void btnDoktorPerformans_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT (v.""ad"" || ' ' || v.""soyad"") as ""Doktor Adı"", 
                       COUNT(r.""randevuId"") as ""Toplam Randevu""
                FROM ""randevular"".""Randevu"" r
                JOIN ""vatandas"".""Doktor"" d ON r.""doktorId"" = d.""doktorId""
                JOIN ""vatandas"".""Vatandas"" v ON d.""doktorId"" = v.""vatandasId""
                GROUP BY v.""ad"", v.""soyad""
                ORDER BY ""Toplam Randevu"" DESC";

            VeriGetir(sql);
        }

        private void btnReceteAnaliz_Click(object sender, EventArgs e)
        {
            string sql = @"
                SELECT i.""ilacAdi"", SUM(rd.""adet"") as ""Toplam Adet""
                FROM ""randevular"".""ReceteDetay"" rd
                JOIN ""randevular"".""Ilaclar"" i ON rd.""ilacId"" = i.""barkod""
                GROUP BY i.""ilacAdi""
                ORDER BY ""Toplam Adet"" DESC";

            VeriGetir(sql);
        }

        private void btnReceteListesi_Click(object sender, EventArgs e)
        {
            string sql = @"
        SELECT 
            r.""receteId"", 
            (v.""ad"" || ' ' || v.""soyad"") as ""Hasta Adı"",
            r.""receteTarihi"",
            ""randevular"".""fn_ReceteIlacSayisi""(r.""receteId"") as ""İlaç Çeşidi Sayısı""
        FROM ""randevular"".""Recete"" r
        JOIN ""vatandas"".""Hasta"" h ON r.""hastaId"" = h.""hastaId""
        JOIN ""vatandas"".""Vatandas"" v ON h.""hastaId"" = v.""vatandasId""
        ORDER BY r.""receteTarihi"" DESC";

            VeriGetir(sql);
        }

        void VeriGetir(string sql)
        {
            try
            {
                DataTable dt = new DataTable();
                using (NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, bgl.Baglanti()))
                {
                    da.Fill(dt);
                }
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri Çekme Hatası: " + ex.Message);
            }
        }
    }
}
