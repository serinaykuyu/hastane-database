﻿namespace HastaneVeritabani
{
    partial class FrmRaporlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRaporlar));
            btnCiroHesapla = new Button();
            lblCiro = new Label();
            btnDoktorPerformans = new Button();
            btnReceteAnaliz = new Button();
            dataGridView1 = new DataGridView();
            btnReceteListesi = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnCiroHesapla
            // 
            btnCiroHesapla.Location = new Point(127, 30);
            btnCiroHesapla.Margin = new Padding(4, 3, 4, 3);
            btnCiroHesapla.Name = "btnCiroHesapla";
            btnCiroHesapla.Size = new Size(288, 44);
            btnCiroHesapla.TabIndex = 0;
            btnCiroHesapla.Text = "Toplam Hastane Cirosu Hesapla";
            btnCiroHesapla.UseVisualStyleBackColor = true;
            btnCiroHesapla.Click += btnCiroHesapla_Click;
            // 
            // lblCiro
            // 
            lblCiro.AutoSize = true;
            lblCiro.Font = new Font("Times New Roman", 32.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblCiro.ForeColor = Color.DarkSlateGray;
            lblCiro.Location = new Point(195, 86);
            lblCiro.Name = "lblCiro";
            lblCiro.Size = new Size(167, 49);
            lblCiro.TabIndex = 1;
            lblCiro.Text = "0.00 TL";
            // 
            // btnDoktorPerformans
            // 
            btnDoktorPerformans.Location = new Point(35, 166);
            btnDoktorPerformans.Name = "btnDoktorPerformans";
            btnDoktorPerformans.Size = new Size(195, 30);
            btnDoktorPerformans.TabIndex = 2;
            btnDoktorPerformans.Text = "Doktor Bazlı Hasta Sayıları";
            btnDoktorPerformans.UseVisualStyleBackColor = true;
            btnDoktorPerformans.Click += btnDoktorPerformans_Click;
            // 
            // btnReceteAnaliz
            // 
            btnReceteAnaliz.Location = new Point(236, 166);
            btnReceteAnaliz.Name = "btnReceteAnaliz";
            btnReceteAnaliz.Size = new Size(161, 30);
            btnReceteAnaliz.TabIndex = 3;
            btnReceteAnaliz.Text = "En Çok Yazılan İlaçlar";
            btnReceteAnaliz.UseVisualStyleBackColor = true;
            btnReceteAnaliz.Click += btnReceteAnaliz_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.Window;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 211);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(545, 280);
            dataGridView1.TabIndex = 4;
            // 
            // btnReceteListesi
            // 
            btnReceteListesi.Location = new Point(403, 166);
            btnReceteListesi.Name = "btnReceteListesi";
            btnReceteListesi.Size = new Size(131, 30);
            btnReceteListesi.TabIndex = 5;
            btnReceteListesi.Text = "Reçete Listesi";
            btnReceteListesi.UseVisualStyleBackColor = true;
            btnReceteListesi.Click += btnReceteListesi_Click;
            // 
            // FrmRaporlar
            // 
            AutoScaleDimensions = new SizeF(9F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(569, 503);
            Controls.Add(btnReceteListesi);
            Controls.Add(dataGridView1);
            Controls.Add(btnReceteAnaliz);
            Controls.Add(btnDoktorPerformans);
            Controls.Add(lblCiro);
            Controls.Add(btnCiroHesapla);
            Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            ForeColor = SystemColors.ControlText;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            Name = "FrmRaporlar";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Raporlar";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCiroHesapla;
        private Label lblCiro;
        private Button btnDoktorPerformans;
        private Button btnReceteAnaliz;
        private DataGridView dataGridView1;
        private Button btnReceteListesi;
    }
}