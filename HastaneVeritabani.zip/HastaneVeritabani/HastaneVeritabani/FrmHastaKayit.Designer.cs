﻿namespace HastaneVeritabani
{
    partial class FrmHastaKayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHastaKayit));
            groupBox1 = new GroupBox();
            txtArama = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnGuncelle = new Button();
            btnSil = new Button();
            btnEkle = new Button();
            btnListele = new Button();
            dataGridView1 = new DataGridView();
            cmbSigorta = new ComboBox();
            txtAdres = new TextBox();
            txtSoyad = new TextBox();
            txtAd = new TextBox();
            mskTC = new MaskedTextBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtArama);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btnGuncelle);
            groupBox1.Controls.Add(btnSil);
            groupBox1.Controls.Add(btnEkle);
            groupBox1.Controls.Add(btnListele);
            groupBox1.Controls.Add(dataGridView1);
            groupBox1.Controls.Add(cmbSigorta);
            groupBox1.Controls.Add(txtAdres);
            groupBox1.Controls.Add(txtSoyad);
            groupBox1.Controls.Add(txtAd);
            groupBox1.Controls.Add(mskTC);
            groupBox1.Location = new Point(15, 0);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(902, 407);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // txtArama
            // 
            txtArama.Location = new Point(219, 372);
            txtArama.Name = "txtArama";
            txtArama.Size = new Size(114, 25);
            txtArama.TabIndex = 1;
            txtArama.TextChanged += txtArama_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label6.Location = new Point(8, 374);
            label6.Name = "label6";
            label6.Size = new Size(205, 19);
            label6.TabIndex = 2;
            label6.Text = "Hasta Ara (Ad Soyad / TC):";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(67, 279);
            label5.Name = "label5";
            label5.Size = new Size(70, 19);
            label5.TabIndex = 14;
            label5.Text = "Sigorta:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(79, 153);
            label4.Name = "label4";
            label4.Size = new Size(58, 19);
            label4.TabIndex = 13;
            label4.Text = "Adres:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(79, 104);
            label3.Name = "label3";
            label3.Size = new Size(58, 19);
            label3.TabIndex = 12;
            label3.Text = "Soyad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(102, 73);
            label2.Name = "label2";
            label2.Size = new Size(35, 19);
            label2.TabIndex = 11;
            label2.Text = "Ad:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(18, 28);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(119, 19);
            label1.TabIndex = 10;
            label1.Text = "TC Kimlik No:";
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(175, 329);
            btnGuncelle.Margin = new Padding(4, 3, 4, 3);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(75, 26);
            btnGuncelle.TabIndex = 9;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(91, 329);
            btnSil.Margin = new Padding(4, 3, 4, 3);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(75, 26);
            btnSil.TabIndex = 8;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(8, 329);
            btnEkle.Margin = new Padding(4, 3, 4, 3);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(75, 26);
            btnEkle.TabIndex = 7;
            btnEkle.Text = "Kaydet";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnListele
            // 
            btnListele.Location = new Point(258, 329);
            btnListele.Margin = new Padding(4, 3, 4, 3);
            btnListele.Name = "btnListele";
            btnListele.Size = new Size(75, 26);
            btnListele.TabIndex = 6;
            btnListele.Text = "Listele";
            btnListele.UseVisualStyleBackColor = true;
            btnListele.Click += btnListele_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.Window;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(356, 24);
            dataGridView1.Margin = new Padding(4, 3, 4, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(538, 373);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // cmbSigorta
            // 
            cmbSigorta.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSigorta.FormattingEnabled = true;
            cmbSigorta.Items.AddRange(new object[] { "SGK", "Özel", "Yok" });
            cmbSigorta.Location = new Point(145, 277);
            cmbSigorta.Margin = new Padding(4, 3, 4, 3);
            cmbSigorta.Name = "cmbSigorta";
            cmbSigorta.Size = new Size(188, 25);
            cmbSigorta.TabIndex = 4;
            // 
            // txtAdres
            // 
            txtAdres.Location = new Point(145, 151);
            txtAdres.Margin = new Padding(4, 3, 4, 3);
            txtAdres.Multiline = true;
            txtAdres.Name = "txtAdres";
            txtAdres.Size = new Size(188, 105);
            txtAdres.TabIndex = 3;
            // 
            // txtSoyad
            // 
            txtSoyad.Location = new Point(145, 102);
            txtSoyad.Margin = new Padding(4, 3, 4, 3);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(157, 25);
            txtSoyad.TabIndex = 2;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(145, 71);
            txtAd.Margin = new Padding(4, 3, 4, 3);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(157, 25);
            txtAd.TabIndex = 1;
            // 
            // mskTC
            // 
            mskTC.Location = new Point(145, 24);
            mskTC.Margin = new Padding(4, 3, 4, 3);
            mskTC.Mask = "00000000000";
            mskTC.Name = "mskTC";
            mskTC.Size = new Size(95, 25);
            mskTC.TabIndex = 0;
            // 
            // FrmHastaKayit
            // 
            AutoScaleDimensions = new SizeF(9F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(930, 414);
            Controls.Add(groupBox1);
            Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            MaximizeBox = false;
            Name = "FrmHastaKayit";
            SizeGripStyle = SizeGripStyle.Hide;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hasta Kayıt";
            Load += FrmHastaKayit_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private MaskedTextBox mskTC;
        private TextBox txtAdres;
        private TextBox txtSoyad;
        private TextBox txtAd;
        private Button btnGuncelle;
        private Button btnSil;
        private Button btnEkle;
        private Button btnListele;
        private DataGridView dataGridView1;
        private ComboBox cmbSigorta;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtArama;
        private Label label6;
    }
}